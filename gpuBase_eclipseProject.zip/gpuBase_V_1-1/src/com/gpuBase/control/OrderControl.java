package com.gpuBase.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gpuBase.model.OrdinazioneBean;
import com.gpuBase.model.OrdinazioneDAO;
import com.gpuBase.model.OrdineBean;
import com.gpuBase.model.OrdineDAO;
import com.gpuBase.model.ProdottoBean;
import com.gpuBase.model.ProdottoDAO;
import com.gpuBase.model.UtenteDAO;
import com.gpuBase.model.VenditoreDAO;

@WebServlet("/order")
public class OrderControl extends HttpServlet {

	private static final long serialVersionUID = 1L;

	OrdinazioneDAO ordinazioneDAO = new OrdinazioneDAO();
	OrdineDAO ordineDAO = new OrdineDAO();
	UtenteDAO utenteDAO = new UtenteDAO();
	VenditoreDAO venditoreDAO = new VenditoreDAO();
	ProdottoDAO prodottoDAO = new ProdottoDAO();
	String toRedirect;

	public OrderControl() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		/*ForTest*/request.getSession().setAttribute("ErrorTextMessage","");
		

		
			doPost(request, response);
			
	

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		request.getSession().setAttribute("toReloadOrder", "no");
		
		String action = request.getParameter("action");
		if(action==null)action=(String) request.getSession().getAttribute("action");	
		
		
		if ("seller".equals(request.getSession().getAttribute("loginType"))) {
		
			toRedirect="/SellerView.jsp";
			try {
				if (action.equals("evadeOrder")) {
					
					
						ordinazioneDAO.doEvade(Integer.parseInt(request.getParameter("idOrdinazione")));
						request.getSession().setAttribute("toReloadOrder", "yes");
				
					/****************************************************************/
				}else if (action.equals("getAllOrders")){
				OrdinazioneDAO ordinazioneDao = new OrdinazioneDAO();
				OrdineDAO ordineDao = new OrdineDAO();				
								
				Collection<OrdinazioneBean> ordinazioni=ordinazioneDao.doRetrieveAll();
				Collection<OrdineBean> ordini=ordineDao.doRetrieveAll();
				
				request.getSession().setAttribute("ordinazioniDB", ordinazioni);			
				request.getSession().setAttribute("ordiniDB", ordini);
				}
			}catch (Exception e) {
				/*ForTest*/request.getSession().setAttribute("ErrorTextMessage","evadeOrderError");
				response.setStatus(409);
				request.getSession().setAttribute("errorMessage", e.getMessage());
			}
		}

		/************************************************************************************************************************************************************/
		

		/* Controllo autenticazione utente con Sessioni */

		if ("registeredUser".equals(request.getSession().getAttribute("loginType"))) {
			
			toRedirect="/HomeView.jsp";
			
			ArrayList<ProdottoBean> productChartList = (ArrayList<ProdottoBean>) request.getSession().getAttribute("productChartList");

			if (productChartList == null) {
				productChartList = new ArrayList<ProdottoBean>();
				request.getSession().setAttribute("productChartList", productChartList);
			}
			// ************************************************************************//

			
			String mailUtente = (String) request.getSession().getAttribute("loginMail");

			try {
				/****************************************************************/
				if (action != null && action.equals("performOrder")) {

					request.getSession().setAttribute("toReloadOrder", "yes");
					request.getSession().setAttribute("orderResult", "done"); // e' temporaneo finche' l'ordinazione non
																				// sara' ultimata con successo

					/* prima di procedere, controllare che ci siano abbastanza pezzi disponibili */

					boolean checked = true;
					for (ProdottoBean prodotto : productChartList) {
						if (prodotto.getNumeroPezzi() > ((prodottoDAO.doRetrieveByKey(prodotto.getIdProdotto())).getNumeroPezzi()))
							{
							checked = false;
							request.getSession().setAttribute("orderResult", "notDone");
							throw new SQLException("not enough pieces");
						}
					}

					if (checked) {

						OrdinazioneBean ordinazione;

						// Ordinazione
						String mail;
						String stato;
						String data;

						OrdineBean ordine;

						// Ordine
						int idOrdinazione;
						int idProdottoAcquistato;
						String nomeAcquisto;
						int numeroPezziAcquistati;
						float prezzoAcquisto;

						// per ogni prodotto presente nel carrello

						for (ProdottoBean prodotto : productChartList) {

							mail = mailUtente;
							stato = "in elaborazione";
							data = java.time.LocalDate.now().toString();

							idProdottoAcquistato = prodotto.getIdProdotto();
							nomeAcquisto = prodotto.getNome();
							numeroPezziAcquistati = prodotto.getNumeroPezzi();
							prezzoAcquisto = prodotto.getPrezzo();

							if (prodottoDAO.doUpdatePezzi(prodotto.getIdProdotto(),(prodottoDAO.doRetrieveByKey(idProdottoAcquistato).getNumeroPezzi())- numeroPezziAcquistati)) 
							{
								
								ordinazione = new OrdinazioneBean(0, mailUtente, stato, data);
								ordinazioneDAO.doSave(ordinazione);
								
								ordine = new OrdineBean(0, ordinazioneDAO.doRetrieveAll().size(), idProdottoAcquistato,nomeAcquisto, numeroPezziAcquistati, prezzoAcquisto);
								ordineDAO.doSave(ordine);

								productChartList = new ArrayList<ProdottoBean>();
								request.getSession().setAttribute("productChartList", productChartList);// svuota
																										// carrello

							} else {
								request.getSession().setAttribute("orderResult", "notDone");
								/*ForTest*/request.getSession().setAttribute("ErrorTextMessage","evadeOrderError");
								throw new SQLException("not enough pieces");
							}

						}

					}

					/****************************************************************/
				
				}
			} catch (SQLException e) {
				/*ForTest*/request.getSession().setAttribute("ErrorTextMessage","evadeOrderError");
				response.setStatus(409);
				request.getSession().setAttribute("errorMessage", e.getMessage());
			}
		}
		/*ForTest*/String doingTest= (String) request.getSession().getAttribute("doingTest");
		
		if(doingTest==null || !(doingTest.equals("true"))) {
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(toRedirect);
		dispatcher.forward(request, response);
		}
	}
}
