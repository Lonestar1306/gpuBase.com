package com.gpuBase.control;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.gpuBase.model.OrdinazioneBean;
import com.gpuBase.model.OrdinazioneDAO;
import com.gpuBase.model.OrdineBean;
import com.gpuBase.model.OrdineDAO;
import com.gpuBase.model.ProdottoBean;
import com.gpuBase.model.ProdottoDAO;

@WebServlet("/product")

public class ProductControl extends HttpServlet {

	
	
	private static final long serialVersionUID = 1L;

	ProdottoDAO prodottoDao = new ProdottoDAO();
	OrdinazioneDAO ordinazioneDAO = new OrdinazioneDAO();

	public ProductControl() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		/*ForTest*/int senty=0;
		
		/*ForTest*/request.getSession().setAttribute("ErrorTextMessage","");
		
		
		
		String action = request.getParameter("action");
		if(action==null)action=(String) request.getSession().getAttribute("action");	
		
		
		
		
		if (action.equals("getProductFoto")) { 
			
			

			byte[] F=null;
			try {
				F = (prodottoDao.doRetrieveByKey(Integer.parseInt(request.getParameter("idProdotto")))).getFoto();
			} catch (Exception e) {
				/*ForTest*/request.getSession().setAttribute("ErrorTextMessage","getProductFotoError");
				e.getMessage();
				}
			

			ServletOutputStream out = response.getOutputStream();
			if (F != null) {
				out.write(F);
				response.setContentType("image/jpeg");
			}
			out.close();

		}
		
		
		if (action.equals("getAllProducts")) {
			
			
			//products contiene tutti i prodotti in vendita
			Collection<ProdottoBean> homeProducts=null;
			try {
				homeProducts = prodottoDao.doRetrieveAll();
				} catch (SQLException e) {
					/*ForTest*/request.getSession().setAttribute("ErrorTextMessage","getAllProductsError");
					e.getMessage();
				}
			
			request.getSession().setAttribute("homeProducts", homeProducts);
			
			}
		
		request.getSession().setAttribute("toReloadHomeProducts", "no");
		
		
		if("seller".equals(request.getSession().getAttribute("loginType")))
		{
			
			
			try {
				if (action != null) 
				{
				
					int idProdotto=0;
					String mailVenditore;
					String nome;
					String descrizione;
					int numeroPezzi;
					float prezzo;
					
					String filePath;
					FileInputStream fis;
					byte[] foto;
					
					
					if(request.getParameter("idProdotto")!=null)
					{
						idProdotto = Integer.parseInt(request.getParameter("idProdotto"));
					}
					
					if (action.equals("deleteProduct")) 
					{
							prodottoDao.doDelete(idProdotto);
							request.getSession().setAttribute("toReloadHomeProducts", "yes");
							
		
					} 
					else if (action.equals("insertProduct")) 
					{
							
						/*ForTest*/senty=1;
							
							mailVenditore =(String) request.getSession().getAttribute("loginMail");
							nome = request.getParameter("nome");
							descrizione = request.getParameter("descrizione");
							
							if(!request.getParameter("numeroPezzi").isEmpty())
								numeroPezzi = Integer.parseInt(request.getParameter("numeroPezzi"));
							else numeroPezzi=-1;
							
							if(!request.getParameter("prezzo").isEmpty())
								prezzo = Float.parseFloat(request.getParameter("prezzo"));
							else prezzo=-1;
							
							filePath=request.getParameter("foto");
							
						
							/*ForTest Selenium*/
							if(nome.length()==0) {nome=null;request.getSession().setAttribute("checkNome", "CasoNomeVuoto");}
							else if(nome.length()>32) {request.getSession().setAttribute("checkNome", "CasoFormatoNomeErrato");}
							else request.getSession().setAttribute("checkNome", null);
							
							if(descrizione.length()==0) {descrizione=null;request.getSession().setAttribute("checkDescrizione", "CasoDescrizioneVuoto");}
							else if(descrizione.length()>255) {request.getSession().setAttribute("checkDescrizione", "CasoFormatoDescrizioneErrato");}
							else request.getSession().setAttribute("checkDescrizione", null);
							
							
							if(numeroPezzi==-1) { request.getSession().setAttribute("checkNumeroPezzi", "CasoNumeroPezziVuoto");}
							else if(String.valueOf(numeroPezzi).length()>8 || numeroPezzi==0) {request.getSession().setAttribute("checkNumeroPezzi", "CasoFormatoNumeroPezziErrato");}
							else request.getSession().setAttribute("checkNumeroPezzi", null);
							
							
							if(prezzo==-1) { request.getSession().setAttribute("checkPrezzo", "CasoPrezzoVuoto");}
							else if(String.valueOf(prezzo).length()>8  || prezzo==0) {request.getSession().setAttribute("checkPrezzo", "CasoFormatoPrezzoErrato");}
							else request.getSession().setAttribute("checkPrezzo", null);
							
							if(filePath.length()==0) {request.getSession().setAttribute("checkFoto", "CasoFotoVuoto");}
							else if(filePath.indexOf(",")!=-1 || filePath.indexOf(";")!=-1  || filePath.indexOf("*")!=-1  
									|| filePath.indexOf("?")!=-1  || filePath.indexOf("<")!=-1  || filePath.indexOf(">")!=-1   || filePath.indexOf("/")!=-1)
								{
									request.getSession().setAttribute("checkFoto", "CasoFormatoFotoErrato");
								}
							else request.getSession().setAttribute("checkFoto", null);
							
							/*ForTest Selenium*/
							
							
							
							
							
							/*For Test Selenium*//*
							System.out.println("Control:checkNome="+request.getSession().getAttribute("checkNome")+";");
							System.out.println("Control:checkDescrizione="+request.getSession().getAttribute("checkDescrizione")+";");
							System.out.println("Control:checkNumeroPezzi="+request.getSession().getAttribute("checkNumeroPezzi")+";");
							System.out.println("Control:checkPrezzo="+request.getSession().getAttribute("checkPrezzo")+";");
							System.out.println("Control:checkFoto="+request.getSession().getAttribute("checkFoto")+";");
							*//*For Test Selenium*/
							
												
							
							
							fis=null;
							
							try 
							{
								
								fis = new FileInputStream(new File(filePath));
								
							}
							catch(FileNotFoundException e) 
							{
								e.getMessage();
							} 
							
							if(fis!=null)
							{
							foto = fis.readAllBytes();
							fis.close();
									
							}else {foto=null;}
							
							
							if(nome!=null && descrizione!=null && numeroPezzi!=-1 && prezzo!=-1)
							{
							ProdottoBean prodotto = new ProdottoBean();
		
							prodotto.setIdProdotto(idProdotto);
							prodotto.setMailVenditore(mailVenditore);
							prodotto.setNome(nome);
							prodotto.setDescrizione(descrizione);
							prodotto.setNumeroPezzi(numeroPezzi);
							prodotto.setPrezzo(prezzo);
							prodotto.setFoto(foto);
		
							prodottoDao.doSave(prodotto);
							
							request.getSession().setAttribute("toReloadHomeProducts", "yes");
							}
							
					}
					else if (action.equals("updateProduct")) 
					{
						
						/*ForTest*/senty=2;
							
						mailVenditore =(String) request.getSession().getAttribute("loginMail");
						nome = request.getParameter("nome");
						descrizione = request.getParameter("descrizione");
						
						if(!request.getParameter("numeroPezzi").isEmpty())
							numeroPezzi = Integer.parseInt(request.getParameter("numeroPezzi"));
						else numeroPezzi=-1;
						
						if(!request.getParameter("prezzo").isEmpty())
							prezzo = Float.parseFloat(request.getParameter("prezzo"));
						else prezzo=-1;
						
						filePath=request.getParameter("foto");
						
						
						/*ForTest Selenium*/
						if(nome.length()==0) {nome=null;request.getSession().setAttribute("checkNome", "CasoNomeVuoto");}
						else if(nome.length()>32) {request.getSession().setAttribute("checkNome", "CasoFormatoNomeErrato");}
						else request.getSession().setAttribute("checkNome", null);
						
						if(descrizione.length()==0) {descrizione=null;request.getSession().setAttribute("checkDescrizione", "CasoDescrizioneVuoto");}
						else if(descrizione.length()>255) {request.getSession().setAttribute("checkDescrizione", "CasoFormatoDescrizioneErrato");}
						else request.getSession().setAttribute("checkDescrizione", null);
						
						if(numeroPezzi==-1) { request.getSession().setAttribute("checkNumeroPezzi", "CasoNumeroPezziVuoto");}
						else if(String.valueOf(numeroPezzi).length()>8 || numeroPezzi==0) {request.getSession().setAttribute("checkNumeroPezzi", "CasoFormatoNumeroPezziErrato");}
						else request.getSession().setAttribute("checkNumeroPezzi", null);
						
						
						if(prezzo==-1) { request.getSession().setAttribute("checkPrezzo", "CasoPrezzoVuoto");}
						else if(String.valueOf(prezzo).length()>8  || prezzo==0) {request.getSession().setAttribute("checkPrezzo", "CasoFormatoPrezzoErrato");}
						else request.getSession().setAttribute("checkPrezzo", null);
						
						
						
						if(filePath.length()==0) {request.getSession().setAttribute("checkFoto", "CasoFotoVuoto");}
						else if(filePath.indexOf(",")!=-1 || filePath.indexOf(";")!=-1  || filePath.indexOf("*")!=-1  
								|| filePath.indexOf("?")!=-1  || filePath.indexOf("<")!=-1  || filePath.indexOf(">")!=-1   || filePath.indexOf("/")!=-1)
							{
								request.getSession().setAttribute("checkFoto", "CasoFormatoFotoErrato");
							}
						else request.getSession().setAttribute("checkFoto", null);
						
						
						
						
						/*ForTest Selenium*/
						
					
						
						
						
						/*For Test Selenium*//*
						System.out.println("Control:checkNome="+request.getSession().getAttribute("checkNome")+";");
						System.out.println("Control:checkDescrizione="+request.getSession().getAttribute("checkDescrizione")+";");
						System.out.println("Control:checkNumeroPezzi="+request.getSession().getAttribute("checkNumeroPezzi")+";");
						System.out.println("Control:checkPrezzo="+request.getSession().getAttribute("checkPrezzo")+";");
						System.out.println("Control:checkFoto="+request.getSession().getAttribute("checkFoto")+";");
						*//*For Test Selenium*/
						
						
							fis=null;
							
							try {
								fis = new FileInputStream(new File(filePath));
							}catch(FileNotFoundException e) {
								e.getMessage();
								} 
							
							if(fis!=null)
							{
							
							foto = fis.readAllBytes();
							fis.close();
							}else foto=null;
							
							
							
							if(nome!=null && descrizione!=null && numeroPezzi!=-1 && prezzo!=-1)
							{
							ProdottoBean prodotto = new ProdottoBean();
			
							prodotto.setIdProdotto(idProdotto);
							prodotto.setMailVenditore(mailVenditore);
							prodotto.setNome(nome);
							prodotto.setDescrizione(descrizione);
							prodotto.setNumeroPezzi(numeroPezzi);
							prodotto.setPrezzo(prezzo);
							prodotto.setFoto(foto);
			
							prodottoDao.doUpdate(prodotto);
							
							request.getSession().setAttribute("toReloadHomeProducts", "yes");
							}
						}
					
					
					
				}
			} catch (SQLException e) {
				
				/*forTest*/
				if(senty==0) {
					request.getSession().setAttribute("ErrorTextMessage","deleteProductError");
				}
				else if(senty==1) {
					request.getSession().setAttribute("ErrorTextMessage","insertProductError");
				}
				else {
					request.getSession().setAttribute("ErrorTextMessage","updateProductError");
				}
				/*forTest*/
				
				response.setStatus(409);
				request.getSession().setAttribute("errorMessage", e.getMessage());
			}
			

		}
		
		/*ForTest*/String doingTest= (String) request.getSession().getAttribute("doingTest");
		
		
		if(!action.equals("getProductFoto") && ( doingTest==null || !(doingTest.equals("true")))) {
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/SellerView.jsp");
		dispatcher.forward(request, response);
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
