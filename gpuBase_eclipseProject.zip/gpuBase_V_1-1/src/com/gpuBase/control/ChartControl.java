package com.gpuBase.control;

import java.io.IOException;
import java.sql.SQLException;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.gpuBase.model.ProdottoBean;
import com.gpuBase.model.ProdottoDAO;



@WebServlet("/chart")
public class ChartControl extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	/*ForTest*/int senty=0;//0=addToChart 1=updatePiecesChart 2=deleteFromChart

	ProdottoDAO prodottoDAO=new ProdottoDAO();


	public ChartControl() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	
		/*ForTest*/request.getSession().setAttribute("ErrorTextMessage","");
		
		
		ArrayList<ProdottoBean> productChartList =(ArrayList<ProdottoBean>) request.getSession().getAttribute("productChartList");
		
		if (productChartList == null) {
			 productChartList=new ArrayList<ProdottoBean>();
			request.getSession().setAttribute("productChartList", productChartList);
		}

		String action = request.getParameter("action");
		
	
		try {
				if (action != null) {
					
					int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));
					
					
					ProdottoBean prodottoDB = prodottoDAO.doRetrieveByKey(idProdotto);
					ProdottoBean prodottoChart=new ProdottoBean();
					
					for(ProdottoBean prod :productChartList ) {
						if(prod.getIdProdotto() == idProdotto) {
							prodottoChart=prod;
							break;
						}
					}
					
					/*******************************************/	
					if (action.equals("addToChart")) {
						
					
						if (!productChartList.contains(prodottoChart)) {// nuovo prodotto
							prodottoChart=prodottoDB;
							prodottoChart.setNumeroPezzi(1);
							productChartList.add(prodottoChart);	
						
						} else { // prodotto già presente nel carrello
							productChartList.remove(prodottoChart);
							prodottoChart.setNumeroPezzi(prodottoChart.getNumeroPezzi()+1);
							productChartList.add(prodottoChart);
						}
	
					/*******************************************/	
					} else if (action.equals("updatePiecesChart")) {
						
						/*ForTest*/senty=1;
						
						/* aggiorna pezzi di un item nel carrello */
						int pezzi = Integer.parseInt(request.getParameter("pezzi"));
						if(pezzi<=prodottoDB.getNumeroPezzi()) {
							productChartList.remove(prodottoChart);
							prodottoChart.setNumeroPezzi(pezzi);
							productChartList.add(prodottoChart);
						}
						
					/*******************************************/	
					} else if (action.equals("deleteFromChart")) {
						
						/*ForTest*/senty=2;
						
						if(productChartList.contains(prodottoChart))
							productChartList.remove(prodottoChart);
					
					} 
					
					
				}
			
		} catch (SQLException e) {
			
			/*ForTest*/
			if(senty==0) {
				request.getSession().setAttribute("ErrorTextMessage","addToChartError");
			}
			else if(senty==1) {
				request.getSession().setAttribute("ErrorTextMessage","updatePiecesChartError");
			}
			else {
				request.getSession().setAttribute("ErrorTextMessage","deleteFromChartError");
			}
			/*forTest*/
			
			
			response.setStatus(409);
			request.getSession().setAttribute("errorMessage", e.getMessage());
		}

		request.getSession().setAttribute("productChartList", productChartList);
		
		/*ForTest*/String doingTest= (String) request.getSession().getAttribute("doingTest");
		
		if(doingTest==null || !(doingTest.equals("true"))) {
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/HomeView.jsp");
		dispatcher.forward(request, response);
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
