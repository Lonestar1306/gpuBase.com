package com.gpuBase.model;

import java.io.Serializable;

public class OrdineBean implements Serializable{
	
	private static final long serialVersionUID = 1L;

	
	public OrdineBean() {
		super();
	}
	
	
	
	
	
	
	public OrdineBean(int idOrdine, int idOrdinazione, int idProdottoAcquistato, String nomeAcquisto,
			int numeroPezziAquistati, float prezzoAcquisto) {
		super();
		this.idOrdine = idOrdine;
		this.idOrdinazione = idOrdinazione;
		this.idProdottoAcquistato = idProdottoAcquistato;
		this.nomeAcquisto = nomeAcquisto;
		this.numeroPezziAquistati = numeroPezziAquistati;
		this.prezzoAcquisto = prezzoAcquisto;
	}






	public int getIdOrdine() {
		return idOrdine;
	}






	public void setIdOrdine(int idOrdine) {
		this.idOrdine = idOrdine;
	}






	public int getIdOrdinazione() {
		return idOrdinazione;
	}






	public void setIdOrdinazione(int idOrdinazione) {
		this.idOrdinazione = idOrdinazione;
	}






	public int getIdProdottoAcquistato() {
		return idProdottoAcquistato;
	}






	public void setIdProdottoAcquistato(int idProdottoAcquistato) {
		this.idProdottoAcquistato = idProdottoAcquistato;
	}






	public String getNomeAcquisto() {
		return nomeAcquisto;
	}






	public void setNomeAcquisto(String nomeAcquisto) {
		this.nomeAcquisto = nomeAcquisto;
	}






	public int getNumeroPezziAquistati() {
		return numeroPezziAquistati;
	}






	public void setNumeroPezziAquistati(int numeroPezziAquistati) {
		this.numeroPezziAquistati = numeroPezziAquistati;
	}






	public float getPrezzoAcquisto() {
		return prezzoAcquisto;
	}






	public void setPrezzoAcquisto(float prezzoAcquisto) {
		this.prezzoAcquisto = prezzoAcquisto;
	}






	public static long getSerialversionuid() {
		return serialVersionUID;
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrdineBean other = (OrdineBean) obj;
		if (idOrdinazione != other.idOrdinazione)
			return false;
		if (idOrdine != other.idOrdine)
			return false;
		if (idProdottoAcquistato != other.idProdottoAcquistato)
			return false;
		if (nomeAcquisto == null) {
			if (other.nomeAcquisto != null)
				return false;
		} else if (!nomeAcquisto.equals(other.nomeAcquisto))
			return false;
		if (numeroPezziAquistati != other.numeroPezziAquistati)
			return false;
		if (Float.floatToIntBits(prezzoAcquisto) != Float.floatToIntBits(other.prezzoAcquisto))
			return false;
		return true;
	}






	@Override
	public String toString() {
		return "OrdineBean [idOrdine=" + idOrdine + ", idOrdinazione=" + idOrdinazione + ", idProdottoAcquistato="
				+ idProdottoAcquistato + ", nomeAcquisto=" + nomeAcquisto + ", numeroPezziAquistati="
				+ numeroPezziAquistati + ", prezzoAcquisto=" + prezzoAcquisto + "]";
	}






	int idOrdine;
	int idOrdinazione;
	int idProdottoAcquistato;
	String nomeAcquisto;
	int numeroPezziAquistati;
	float prezzoAcquisto;
}
