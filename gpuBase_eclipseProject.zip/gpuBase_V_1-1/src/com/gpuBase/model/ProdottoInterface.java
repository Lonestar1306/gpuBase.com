package com.gpuBase.model;

import java.sql.SQLException;
import java.util.Collection;

public interface ProdottoInterface {

	
	public void doSave(ProdottoBean prodotto) throws SQLException;
	
	public boolean doUpdate(ProdottoBean prodotto)throws SQLException;
	
	public boolean doUpdatePezzi(int idProdotto,int numeroPezzi)throws SQLException;

	public boolean doDelete(int idProdotto) throws SQLException;

	public ProdottoBean doRetrieveByKey(int idProdotto) throws SQLException;
	
	public Collection<ProdottoBean> doRetrieveAll() 
			throws SQLException;

	
	
}
