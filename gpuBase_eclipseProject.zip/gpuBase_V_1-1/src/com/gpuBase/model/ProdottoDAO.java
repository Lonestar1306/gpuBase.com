package com.gpuBase.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

/*import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;*/

public class ProdottoDAO implements ProdottoInterface {

	/*
private static DataSource ds;
	
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/gpuBase");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	
	*/

	private static final String TABLE_NAME = "Prodotto";
	/****************************************************************/
	
	@Override
	public void doSave(ProdottoBean prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		/*
		String insertSQL = "INSERT INTO " + ProdottoDAO.TABLE_NAME
				+ " (idProdotto, mailVenditore, nome, descrizione, numeroPezzi, prezzo, foto)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?)";
		*/
		
		String insertSQL = "INSERT INTO " + ProdottoDAO.TABLE_NAME
				+ " (mailVenditore, nome, descrizione, numeroPezzi, prezzo, foto)"
				+ " VALUES (?, ?, ?, ?, ?, ?)";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			//preparedStatement.setInt(1, prodotto.getIdProdotto());
			preparedStatement.setString(1, prodotto.getMailVenditore());
			preparedStatement.setString(2, prodotto.getNome());
			preparedStatement.setString(3, prodotto.getDescrizione());
			preparedStatement.setInt(4, prodotto.getNumeroPezzi());
			preparedStatement.setDouble(5, prodotto.getPrezzo());
			preparedStatement.setBytes(6, prodotto.getFoto());
			preparedStatement.executeUpdate();
			
			connection.commit();
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}

	/****************************************************************/
	
	@Override
	public boolean doDelete(int idProdotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM " + ProdottoDAO.TABLE_NAME + " WHERE idProdotto = ?";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, idProdotto);

			result = preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	/****************************************************************/
	
	@Override
	public ProdottoBean doRetrieveByKey(int idProdotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ProdottoBean bean = new ProdottoBean();

		String selectSQL = "SELECT * FROM " + ProdottoDAO.TABLE_NAME + " WHERE idProdotto = ?";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, idProdotto);
			
			ResultSet rs = preparedStatement.executeQuery();
			connection.commit();

			while (rs.next()) {
				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setMailVenditore(rs.getString("mailVenditore"));
				bean.setNome(rs.getString("nome"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setNumeroPezzi(rs.getInt("numeroPezzi"));
				bean.setPrezzo(rs.getFloat("prezzo"));
				bean.setFoto(rs.getBytes("foto"));
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	@Override
	public Collection<ProdottoBean> doRetrieveAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ProdottoBean> products = new LinkedList<ProdottoBean>();

		String selectSQL = "SELECT * FROM " + ProdottoDAO.TABLE_NAME;



		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();
			connection.commit();

			while (rs.next()) {
				ProdottoBean bean = new ProdottoBean();

				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setMailVenditore(rs.getString("mailVenditore"));
				bean.setNome(rs.getString("nome"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setNumeroPezzi(rs.getInt("numeroPezzi"));
				bean.setPrezzo(rs.getFloat("prezzo"));
				bean.setFoto(rs.getBytes("foto"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	@Override
	public boolean doUpdatePezzi(int idProdotto, int numeroPezzi) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String updateSQL = "UPDATE " + ProdottoDAO.TABLE_NAME + " SET numeroPezzi = ? WHERE idProdotto = ?"; 

		try {
			
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);
			preparedStatement.setInt(1, numeroPezzi);
			preparedStatement.setInt(2, idProdotto);

			result = preparedStatement.executeUpdate();
			connection.commit();

		
		} 
		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	@Override
	public boolean doUpdate(ProdottoBean prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String updateSQL = "UPDATE " + ProdottoDAO.TABLE_NAME + " SET mailVenditore = ? ,nome = ? ,descrizione = ? ,numeroPezzi = ? ,prezzo = ? ,foto = ?  WHERE idProdotto = ?"; 

		try {
			
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);
			preparedStatement.setString(1, prodotto.getMailVenditore());
			preparedStatement.setString(2, prodotto.getNome());
			preparedStatement.setString(3, prodotto.getDescrizione());
			preparedStatement.setInt(4, prodotto.getNumeroPezzi());
			preparedStatement.setFloat(5, prodotto.getPrezzo());
			preparedStatement.setBytes(6, prodotto.getFoto());
			preparedStatement.setInt(7, prodotto.getIdProdotto());

			result = preparedStatement.executeUpdate();
			connection.commit();

		
		} 
		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	

}
