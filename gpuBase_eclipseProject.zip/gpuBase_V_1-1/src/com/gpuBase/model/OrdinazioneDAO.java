package com.gpuBase.model;


import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

/*
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class OrdinazioneDAO implements OrdinazioneInterface{


/*
	private static DataSource ds;
	
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/gpuBase");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
*/
	private static final String TABLE_NAME = "Ordinazione";
	/****************************************************************/
	
	@Override
	public void doSave(OrdinazioneBean ordinazione) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		
		/*
		String insertSQL = "INSERT INTO " + OrdinazioneDAO.TABLE_NAME
				+ " (idOrdinazione,mailUtente,stato,data)"
				+ " VALUES (?, ?, ?, ?)";
		*/
		
		String insertSQL = "INSERT INTO " + OrdinazioneDAO.TABLE_NAME
				+ " (mailUtente,stato,data)"
				+ " VALUES (?, ?, ?)";

		try {
			connection= DriverManagerConnectionPool.getConnection();
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			
			
		
			//preparedStatement.setInt(1, ordinazione.getIdOrdinazione());
			preparedStatement.setString(1, ordinazione.getMailUtente());
			preparedStatement.setString(2, ordinazione.getStato());
			preparedStatement.setString(3, ordinazione.getData());
	
			
			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	
	
	/*************************************************************/
	@Override
	public boolean doDelete(int idOrdinazione) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM " + OrdinazioneDAO.TABLE_NAME + " WHERE idOrdinazione = ?";

		try {
			connection= DriverManagerConnectionPool.getConnection();
			//connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, idOrdinazione);

			result = preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}
	
	

	/******************************************/
	@Override
	public OrdinazioneBean doRetrieveByKey(int idOrdinazione) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		OrdinazioneBean bean = new OrdinazioneBean();

		String selectSQL = "SELECT * FROM " + OrdinazioneDAO.TABLE_NAME + " WHERE idOrdinazione = ?";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, idOrdinazione);

			ResultSet rs = preparedStatement.executeQuery();
			connection.commit();

			while (rs.next()) {
				bean.setIdOrdinazione(rs.getInt("idOrdinazione"));
				bean.setMailUtente(rs.getString("mailUtente"));
				bean.setStato(rs.getString("stato"));
				bean.setData(rs.getString("data"));
				
				
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	/***********************************************/
	@Override
	public Collection<OrdinazioneBean> doRetrieveAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<OrdinazioneBean> ordinazioni = new LinkedList<OrdinazioneBean>();

		String selectSQL = "SELECT * FROM " + OrdinazioneDAO.TABLE_NAME;
		

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();
			connection.commit();


			while (rs.next()) {
				OrdinazioneBean bean = new OrdinazioneBean();


				bean.setIdOrdinazione(rs.getInt("idOrdinazione"));
				bean.setMailUtente(rs.getString("mailUtente"));
				bean.setStato(rs.getString("stato"));
				bean.setData(rs.getString("data"));
				
				
				ordinazioni.add(bean);	
				
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return ordinazioni;
	}
	
	
	
	/*************************************************************************/
	@Override
	public Collection<OrdinazioneBean> doRetrieveAllByUser(String mailUtente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<OrdinazioneBean> ordinazioni = new LinkedList<OrdinazioneBean>();

		String selectSQL = "SELECT * FROM " + OrdinazioneDAO.TABLE_NAME + " WHERE mailUtente = ? ORDER BY data DESC";
		

		
		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, mailUtente);

			ResultSet rs = preparedStatement.executeQuery();
			connection.commit();


			while (rs.next()) {
				OrdinazioneBean bean = new OrdinazioneBean();


				bean.setIdOrdinazione(rs.getInt("idOrdinazione"));
				bean.setMailUtente(rs.getString("mailUtente"));
				bean.setStato(rs.getString("stato"));
				bean.setData(rs.getString("data"));
				
				ordinazioni.add(bean);	
				
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return ordinazioni;
	}


	@Override
	public boolean doEvade(int idOrdinazione) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String updateSQL = "UPDATE " + OrdinazioneDAO.TABLE_NAME + " SET stato = ? WHERE idOrdinazione = ?"; 

		try {
			
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);
			preparedStatement.setString(1, "spedito");
			preparedStatement.setInt(2, idOrdinazione);

			result = preparedStatement.executeUpdate();
			connection.commit();

		
		} 
		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}
	



}



