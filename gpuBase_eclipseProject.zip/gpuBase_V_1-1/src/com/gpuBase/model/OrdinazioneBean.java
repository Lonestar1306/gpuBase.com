package com.gpuBase.model;

import java.io.Serializable;

public class OrdinazioneBean implements Serializable{


	private static final long serialVersionUID = 1L;
	
	public OrdinazioneBean() {
		super();
	}




	
	public OrdinazioneBean(int idOrdinazione, String mailUtente, String stato, String data) {
		super();
		this.idOrdinazione = idOrdinazione;
		this.mailUtente = mailUtente;
		this.stato = stato;
		this.data = data;
	}





	public int getIdOrdinazione() {
		return idOrdinazione;
	}





	public void setIdOrdinazione(int idOrdinazione) {
		this.idOrdinazione = idOrdinazione;
	}





	public String getMailUtente() {
		return mailUtente;
	}





	public void setMailUtente(String mailUtente) {
		this.mailUtente = mailUtente;
	}





	public String getStato() {
		return stato;
	}





	public void setStato(String stato) {
		this.stato = stato;
	}





	public String getData() {
		return data;
	}





	public void setData(String data) {
		this.data = data;
	}





	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrdinazioneBean other = (OrdinazioneBean) obj;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		if (idOrdinazione != other.idOrdinazione)
			return false;
		if (mailUtente == null) {
			if (other.mailUtente != null)
				return false;
		} else if (!mailUtente.equals(other.mailUtente))
			return false;
		if (stato == null) {
			if (other.stato != null)
				return false;
		} else if (!stato.equals(other.stato))
			return false;
		return true;
	}





	@Override
	public String toString() {
		return "OrdinazioneBean [idOrdinazione=" + idOrdinazione + ", mailUtente=" + mailUtente + ", stato=" + stato
				+ ", data=" + data + "]";
	}




	
	
	
	int idOrdinazione;
	String mailUtente;
	String stato;
	String data;

}
