package com.gpuBase.model;

import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

/*
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class OrdineDAO implements OrdineInterface{

	/*
private static DataSource ds;
	
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/gpuBase");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	
	*/

	private static final String TABLE_NAME = "Ordine";
	
	/****************************************************************/


	@Override
	public void doSave(OrdineBean ordine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		/*
		String insertSQL = "INSERT INTO " + OrdineDAO.TABLE_NAME
				+ " (idOrdine,idOrdinazione,idProdottoAcquistato,nomeAcquisto,numeroPezziAcquistati,prezzoAcquisto)"
				+ " VALUES (?, ?, ?, ?, ?, ?)";
		*/
		
		String insertSQL = "INSERT INTO " + OrdineDAO.TABLE_NAME
				+ " (idOrdinazione,idProdottoAcquistato,nomeAcquisto,numeroPezziAcquistati,prezzoAcquisto)"
				+ " VALUES (?, ?, ?, ?, ?)";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			
			
			//preparedStatement.setInt(1, ordinazione.getIdOrdine());
			//preparedStatement.setInt(1, ordine.getIdOrdine());
			preparedStatement.setInt(1, ordine.getIdOrdinazione());
			preparedStatement.setInt(2, ordine.getIdProdottoAcquistato());
			preparedStatement.setString(3, ordine.getNomeAcquisto());
			preparedStatement.setInt(4, ordine.getNumeroPezziAquistati());
			preparedStatement.setFloat(5, ordine.getPrezzoAcquisto());
			
	
			
			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
	}

	
	/****************************************************************/

	@Override
	public boolean doDelete(int idOrdine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM " + OrdineDAO.TABLE_NAME + " WHERE idOrdine = ?";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, idOrdine);

			result = preparedStatement.executeUpdate();
			
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}
	
	
	/****************************************************************/


	@Override
	public OrdineBean doRetrieveByKey(int idOrdine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		OrdineBean bean = new OrdineBean();

		String selectSQL = "SELECT * FROM " + OrdineDAO.TABLE_NAME + " WHERE idOrdine = ?";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, idOrdine);

			ResultSet rs = preparedStatement.executeQuery();
			
			connection.commit();

			while (rs.next()) {
				bean.setIdOrdine(rs.getInt("idOrdine"));
				bean.setIdOrdinazione(rs.getInt("idOrdinazione"));
				bean.setIdProdottoAcquistato(rs.getInt("IdProdottoAcquistato"));
				bean.setNomeAcquisto(rs.getString("nomeAcquisto"));
				bean.setNumeroPezziAquistati(rs.getInt("numeroPezziAcquistati"));
				bean.setPrezzoAcquisto(rs.getFloat("prezzoAcquisto"));
				
				
			}
			
			

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
		
	}
	
	/****************************************************************/


	@Override
	public Collection<OrdineBean> doRetrieveAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<OrdineBean> ordini = new LinkedList<OrdineBean>();

		String selectSQL = "SELECT * FROM " + OrdineDAO.TABLE_NAME;
		

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();
			connection.commit();

			while (rs.next()) {
				OrdineBean bean = new OrdineBean();


				bean.setIdOrdine(rs.getInt("idOrdine"));
				bean.setIdOrdinazione(rs.getInt("idOrdinazione"));
				bean.setIdProdottoAcquistato(rs.getInt("IdProdottoAcquistato"));
				bean.setNomeAcquisto(rs.getString("nomeAcquisto"));
				bean.setNumeroPezziAquistati(rs.getInt("numeroPezziAcquistati"));
				bean.setPrezzoAcquisto(rs.getFloat("prezzoAcquisto"));
				
				
				ordini.add(bean);	
				
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return ordini;
	}
	
	
	
	
	
	
	
	
	
	
	
}
