package com.gpuBase.model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

/*
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
*/

public class VenditoreDAO implements VenditoreInterface {

	
	/*
private static DataSource ds;
	
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");
	
			ds = (DataSource) envCtx.lookup("jdbc/gpuBase");
	
		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
			
	*/
	

	private static final String TABLE_NAME = "Venditore";
	/****************************************************************/
	
	@Override
	public void doSave(VenditoreBean venditore) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + VenditoreDAO.TABLE_NAME
				+ " (mail,password) VALUES (?, ?)";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, venditore.getMail());
			preparedStatement.setString(2, venditore.getPassword());
			
			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
	}
	
	/****************************************************************/

	@Override
	public boolean doDelete(String mail) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM " + VenditoreDAO.TABLE_NAME + " WHERE mail = ?";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setString(1, mail);

			
			
			result = preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	
	/****************************************************************/
	
	@Override
	public VenditoreBean doRetrieveByKey(String mail) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		VenditoreBean bean = new VenditoreBean();

		String selectSQL = "SELECT * FROM " + VenditoreDAO.TABLE_NAME + " WHERE mail = ?";

		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, mail);

			ResultSet rs = preparedStatement.executeQuery();
			connection.commit();
			
			while (rs.next()) {
				bean.setMail(rs.getString("mail"));
				bean.setPassword(rs.getString("password"));
			}
			

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}
	
	/****************************************************************/

	@Override
	public Collection<VenditoreBean> doRetrieveAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<VenditoreBean> venditori = new LinkedList<VenditoreBean>();

		String selectSQL = "SELECT * FROM " + VenditoreDAO.TABLE_NAME;


		try {
			//connection = ds.getConnection();
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();
			connection.commit();

			while (rs.next()) {
				VenditoreBean bean = new VenditoreBean();
				bean.setMail(rs.getString("mail"));
				bean.setPassword(rs.getString("password"));
				
				venditori.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return venditori;
	}
	

	}
