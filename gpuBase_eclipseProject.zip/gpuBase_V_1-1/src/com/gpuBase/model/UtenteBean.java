package com.gpuBase.model;

public class UtenteBean {
	
	public UtenteBean() {
		super();
	}
	
	public UtenteBean(String mail, String password, String cellulare, String indirizzoSpedizione) {
		super();
		this.mail = mail;
		this.password = password;
		this.cellulare = cellulare;
		this.indirizzoSpedizione = indirizzoSpedizione;
	}
	
	
	
	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCellulare() {
		return cellulare;
	}

	public void setCellulare(String cellulare) {
		this.cellulare = cellulare;
	}

	public String getIndirizzoSpedizione() {
		return indirizzoSpedizione;
	}

	public void setIndirizzoSpedizione(String indirizzoSpedizione) {
		this.indirizzoSpedizione = indirizzoSpedizione;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UtenteBean other = (UtenteBean) obj;
		if (cellulare == null) {
			if (other.cellulare != null)
				return false;
		} else if (!cellulare.equals(other.cellulare))
			return false;
		if (indirizzoSpedizione == null) {
			if (other.indirizzoSpedizione != null)
				return false;
		} else if (!indirizzoSpedizione.equals(other.indirizzoSpedizione))
			return false;
		if (mail == null) {
			if (other.mail != null)
				return false;
		} else if (!mail.equals(other.mail))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UtenteBean [mail=" + mail + ", password=" + password + ", cellulare=" + cellulare
				+ ", indirizzoSpedizione=" + indirizzoSpedizione + "]";
	}



	private String mail;
	private String password;
	private String cellulare;
	private String indirizzoSpedizione;
}
