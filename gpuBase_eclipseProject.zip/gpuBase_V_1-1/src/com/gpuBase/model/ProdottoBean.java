package com.gpuBase.model;

import java.util.Arrays;

public class ProdottoBean {

	public ProdottoBean() {
		super();
	}
	
	public ProdottoBean(int idProdotto, String mailVenditore, String nome, String descrizione, int numeroPezzi,
			float prezzo, byte[] foto) {
		super();
		this.idProdotto = idProdotto;
		this.mailVenditore = mailVenditore;
		this.nome = nome;
		this.descrizione = descrizione;
		this.numeroPezzi = numeroPezzi;
		this.prezzo = prezzo;
		this.foto = foto;
	}
	
	public int getIdProdotto() {
		return idProdotto;
	}

	public void setIdProdotto(int idProdotto) {
		this.idProdotto = idProdotto;
	}

	public String getMailVenditore() {
		return mailVenditore;
	}

	public void setMailVenditore(String mailVenditore) {
		this.mailVenditore = mailVenditore;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public int getNumeroPezzi() {
		return numeroPezzi;
	}

	public void setNumeroPezzi(int numeroPezzi) {
		this.numeroPezzi = numeroPezzi;
	}

	public float getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(float prezzo) {
		this.prezzo = prezzo;
	}

	public byte[] getFoto() {
		return foto;
	}

	public void setFoto(byte[] foto) {
		this.foto = foto;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProdottoBean other = (ProdottoBean) obj;
		if (descrizione == null) {
			if (other.descrizione != null)
				return false;
		} else if (!descrizione.equals(other.descrizione))
			return false;
		if (!Arrays.equals(foto, other.foto))
			return false;
		if (idProdotto != other.idProdotto)
			return false;
		if (mailVenditore == null) {
			if (other.mailVenditore != null)
				return false;
		} else if (!mailVenditore.equals(other.mailVenditore))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (numeroPezzi != other.numeroPezzi)
			return false;
		if (Float.floatToIntBits(prezzo) != Float.floatToIntBits(other.prezzo))
			return false;
		return true;
	}	

	@Override
	public String toString() {
		return "ProdottoBean [idProdotto=" + idProdotto + ", mailVenditore=" + mailVenditore + ", nome=" + nome
				+ ", descrizione=" + descrizione + ", numeroPezzi=" + numeroPezzi + ", prezzo=" + prezzo + ", foto="
				+ Arrays.toString(foto) + "]";
	}



	private int idProdotto;
	private String mailVenditore;
	private String nome;
	private String descrizione;
	private int numeroPezzi;
	private float prezzo;
	private byte[] foto;
}
