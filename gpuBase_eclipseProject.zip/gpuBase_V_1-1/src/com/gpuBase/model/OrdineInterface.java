package com.gpuBase.model;

import java.sql.SQLException;
import java.util.Collection;

public interface OrdineInterface {
	
	public void doSave(OrdineBean ordine) throws SQLException;

	public boolean doDelete(int idOrdine) throws SQLException;

	public OrdineBean doRetrieveByKey(int idOrdine) throws SQLException;
	
	public Collection<OrdineBean> doRetrieveAll() throws SQLException;
	

}
