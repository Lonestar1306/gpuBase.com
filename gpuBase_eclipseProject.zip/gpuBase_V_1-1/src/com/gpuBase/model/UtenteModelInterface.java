package com.gpuBase.model;

import java.sql.SQLException;
import java.util.Collection;

public interface UtenteModelInterface {

    public boolean doDelete(String mail) throws SQLException;

    public UtenteBean doRetrieveByKey(String mail) throws SQLException;

    public Collection<UtenteBean> doRetrieveAll() 
            throws SQLException;

    void doSave(UtenteBean utente) throws SQLException;
}
