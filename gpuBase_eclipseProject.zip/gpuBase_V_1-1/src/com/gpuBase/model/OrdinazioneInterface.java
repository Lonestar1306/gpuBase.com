package com.gpuBase.model;


import java.sql.SQLException;
import java.util.Collection;


public interface OrdinazioneInterface {


	public void doSave(OrdinazioneBean ordinazione) throws SQLException;

	public boolean doDelete(int idOrdinazione) throws SQLException;
	
	public boolean doEvade(int idOrdinazione) throws SQLException;

	public OrdinazioneBean doRetrieveByKey(int idOrdinazione) throws SQLException;
	
	public Collection<OrdinazioneBean> doRetrieveAll() throws SQLException;
	
	public Collection<OrdinazioneBean> doRetrieveAllByUser(String mailUtente) throws SQLException;
	
	
	
}

