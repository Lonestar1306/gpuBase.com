package com.gpuBase.model;

import java.sql.SQLException;
import java.util.Collection;

public interface VenditoreInterface {

    public void doSave(VenditoreBean venditore) throws SQLException;

    public boolean doDelete(String mailVenditore) throws SQLException;

    public VenditoreBean doRetrieveByKey(String mailVenditore) throws SQLException;

    public Collection<VenditoreBean> doRetrieveAll() throws SQLException;
	
}
