package com.gpuBase.test.control;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestChartControl.class, TestOrderControl.class, TestProductControl.class })
public class AllTestsControl {

}
