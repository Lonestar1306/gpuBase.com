package com.gpuBase.test.control;


import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockPart;

import com.gpuBase.control.ChartControl;
import com.gpuBase.model.ProdottoBean;
import com.gpuBase.model.ProdottoDAO;

import junit.framework.TestCase;

public class TestChartControl extends TestCase {
		
	
	
	public TestChartControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TestChartControl(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	
	@InjectMocks
	private ChartControl servlet;
	
	private ProdottoBean prodotto=new ProdottoBean(1,"sellermail","name","desc",1,1,null);
	
	
	@BeforeEach
	protected
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();

	}

	@AfterEach
	protected
	void tearDown() throws Exception {
		request=null;
		response=null;

	}
	
	
	
	
	@Test
	public void test1() throws ServletException, IOException { //addToChart
		request.getSession().setAttribute("doingTest","true");
		ArrayList<ProdottoBean> productChartList=new ArrayList<ProdottoBean>();
		ProdottoBean prodottoTest=new ProdottoBean(1,"sellerTest1","nome","desc",1,1,null); 
		productChartList.add(prodottoTest);
		request.setParameter("action","addToChart");
		request.setParameter("idProdotto",1+"");
		request.getSession().setAttribute("productChartList",productChartList);
		
		
		
		servlet.doPost(request, response);
		

		String message="addToChartError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}
	
	@Test
	public void test2() throws ServletException, IOException { //updatePiecesChart
		request.getSession().setAttribute("doingTest","true");
		ArrayList<ProdottoBean> productChartList=new ArrayList<ProdottoBean>();
		ProdottoBean prodottoTest=new ProdottoBean(1,"sellerTest1","nome","desc",1,1,null); 
		productChartList.add(prodottoTest);
		request.setParameter("idProdotto",1+"");
		request.setParameter("action","updatePiecesChart");
		request.setParameter("pezzi",10+"");
		request.getSession().setAttribute("productChartList",productChartList);
		
		
		
		servlet.doPost(request, response);
		

		String message="updatePiecesChartError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}

	@Test
	public void test3() throws ServletException, IOException { //deleteFromChart
		request.getSession().setAttribute("doingTest","true");
		ArrayList<ProdottoBean> productChartList=new ArrayList<ProdottoBean>();
		ProdottoBean prodottoTest=new ProdottoBean(1,"sellerTest1","nome","desc",1,1,null); 
		productChartList.add(prodottoTest);
		request.setParameter("action","deleteFromChart");
		request.getSession().setAttribute("loginType","registeredUser");
		request.setParameter("idProdotto",1+"");
		request.getSession().setAttribute("productChartList",productChartList);
		
		
		
		servlet.doPost(request, response);
		

		String message="deleteFromChartError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}


}
