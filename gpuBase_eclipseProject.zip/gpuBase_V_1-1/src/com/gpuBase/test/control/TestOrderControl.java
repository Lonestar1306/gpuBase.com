package com.gpuBase.test.control;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.gpuBase.control.ChartControl;
import com.gpuBase.control.OrderControl;
import com.gpuBase.model.OrdineBean;
import com.gpuBase.model.OrdineDAO;
import com.gpuBase.model.ProdottoBean;

import junit.framework.TestCase;

public class TestOrderControl extends TestCase {

	
	public TestOrderControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TestOrderControl(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	
	@Mock
	private OrdineDAO dao;
	
	@InjectMocks
	private OrderControl servlet;
	

	
	private OrdineBean ordine=new OrdineBean(1,1,1,"name",1,1);
	
	@BeforeEach
	protected
	void setUp() throws Exception{ 
		MockitoAnnotations.initMocks(this);
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
	
	}

	@AfterEach
	protected
	void tearDown() throws Exception {	
		request=null;
		response=null;
	}

	@Test
	public void test1() throws ServletException, IOException { //performOrder
		request.getSession().setAttribute("doingTest","true");
		ArrayList<ProdottoBean> productChartList=new ArrayList<ProdottoBean>();
		ProdottoBean prodottoTest=new ProdottoBean(1,"sellerTest1","nome","desc",1,1,null); 
		productChartList.add(prodottoTest);
		request.setParameter("action","performOrder");
		request.getSession().setAttribute("loginType","registeredUser");
		request.setParameter("idOrdinazione",1+"");
		request.getSession().setAttribute("productChartList",productChartList);
		
		
		
		servlet.doPost(request, response);
		

		String message="performOrderError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}
	
	@Test
	public void test2() throws ServletException, IOException { //evadeOrder
		request.getSession().setAttribute("doingTest","true");
		ArrayList<ProdottoBean> productChartList=new ArrayList<ProdottoBean>();
		ProdottoBean prodottoTest=new ProdottoBean(1,"sellerTest1","nome","desc",1,1,null); 
		productChartList.add(prodottoTest);
		request.setParameter("action","evadeOrder");
		request.getSession().setAttribute("loginType","registeredUser");
		request.setParameter("idOrdinazione",1+"");
		request.getSession().setAttribute("productChartList",productChartList);
		
		
		
		servlet.doPost(request, response);
		

		String message="evadeOrderError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}



}
