package com.gpuBase.test.control;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.gpuBase.control.ChartControl;
import com.gpuBase.control.ProductControl;
import com.gpuBase.model.ProdottoBean;

import junit.framework.TestCase;

public class TestProductControl extends TestCase {

	public TestProductControl() {
		super();
		// TODO Auto-generated constructor stub
	}




	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	
	@InjectMocks
	private ProductControl servlet;
	
	private ProdottoBean prodotto=new ProdottoBean(1,"sellermail","name","desc",1,1,null);
	
	
	@BeforeEach
	protected
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();

	}

	@AfterEach
	protected
	void tearDown() throws Exception {
		request=null;
		response=null;

	}
	
	
	
	
	@Test
	public void test1() throws ServletException, IOException { //getAllProducts
		request.getSession().setAttribute("doingTest","true");
		request.setParameter("action","getAllProducts");
		request.setParameter("idProdotto","1");
	
		servlet.doPost(request, response);
		

		String message="getAllProductsError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}
	
	@Test
	public void test2() throws ServletException, IOException { //deleteProduct
		request.getSession().setAttribute("loginType","seller");
		request.getSession().setAttribute("doingTest","true");
		request.setParameter("idProdotto",1+"");
		request.setParameter("action","deleteProduct");
	
		
		
		servlet.doPost(request, response);
		

		String message="deleteProductError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}

	@Test
	public void test3() throws ServletException, IOException { //insertProduct
		request.getSession().setAttribute("loginType","seller");
		request.getSession().setAttribute("doingTest","true");
		request.setParameter("action","insertProduct");
		request.setParameter("idProdotto",1+"");
		 request.getSession().setAttribute("loginMail","userTest1");
		 request.setParameter("nome","name");
		 request.setParameter("descrizione","desc");
		 request.setParameter("numeroPezzi","1");
	     request.setParameter("prezzo","1");
	     request.setParameter("foto","");
		
		
		
		servlet.doPost(request, response);
		

		String message="insertProductError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}

	
	@Test
	public void test4() throws ServletException, IOException { //updateProduct
		request.getSession().setAttribute("loginType","seller");
		request.getSession().setAttribute("doingTest","true");
		request.setParameter("action","updateProduct");
		request.setParameter("idProdotto",1+"");
		 request.getSession().setAttribute("loginMail","userTest1");
		 request.setParameter("nome","name");
		 request.setParameter("descrizione","desc");
		 request.setParameter("numeroPezzi","1");
	     request.setParameter("prezzo","1");
	     request.setParameter("foto","");
		
		
		
		servlet.doPost(request, response);
		

		String message="updateProductError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}
	
	
	@Test
	public void test5() throws ServletException, IOException { //getProductFoto
		
		request.getSession().setAttribute("doingTest","true");
		request.setParameter("action","getProductFoto");
		request.setParameter("idProdotto",1+"");
		
		
		servlet.doPost(request, response);
		

		String message="getProductFotoError";
		String result = (String) request.getAttribute("ErrorTextMessage");
		assertNotEquals(message, result);
	}

}
