package com.gpuBase.test.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.gpuBase.model.VenditoreBean;
import com.gpuBase.model.VenditoreDAO;

import junit.framework.TestCase;

public class TestVenditoreDAO extends TestCase{

	void TestCase() {}
	
	public TestVenditoreDAO() {
		super();
	}


	VenditoreDAO testDao;
	VenditoreBean testBean;

	@BeforeEach
	protected
	void setUp() throws Exception {
		testDao = new VenditoreDAO();
		testBean = new VenditoreBean("sellerMail", "sellerPassword");
	}

	@AfterEach
	protected
	void tearDown() throws Exception {
		testDao = null;
		testBean = null;
	}

	@Test
	public final void test1() {//DoSave
		try {
			ResetDB r=new ResetDB();

			testDao.doSave(testBean);
			VenditoreBean testBean2 = testDao.doRetrieveByKey(testBean.getMail());

			assertEquals(testBean, testBean2);

		} catch (SQLException e) {
			fail(e.getMessage());
		}
	}

	

	@Test
	public final void test2() {//RetriveByKey

		try {
			assertEquals(testBean, testDao.doRetrieveByKey(testBean.getMail()));
		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}

	@Test
	public final void test3() {//RetriveAll

		ArrayList<VenditoreBean> collection = new ArrayList<VenditoreBean>();

		try {

			assertNotEquals(collection, testDao.doRetrieveAll());

		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}
	
	@Test
	public final void test4() {//DoDelete

		try {

			assertEquals(true, testDao.doDelete(testBean.getMail()));

		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}

}
