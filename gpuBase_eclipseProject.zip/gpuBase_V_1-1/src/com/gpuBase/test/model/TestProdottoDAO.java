package com.gpuBase.test.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.gpuBase.model.ProdottoDAO;
import com.gpuBase.model.VenditoreBean;
import com.gpuBase.model.VenditoreDAO;

import junit.framework.TestCase;

import com.gpuBase.model.ProdottoBean;

public class TestProdottoDAO extends TestCase{
	
	
	
	
	public TestProdottoDAO() {
		super();
		
	}

	

	ProdottoDAO testDao=new ProdottoDAO();;
	ProdottoBean testBean= new ProdottoBean(1, "sellerTest1", "nome", "desc", 5, 50, null);;

	VenditoreDAO  venditoreDAO=new VenditoreDAO();
	VenditoreBean venditoreBean=new VenditoreBean("sellerTest1","1234");
	
	Collection<ProdottoBean> list;

	
	@BeforeEach
	@Override
	protected
	void setUp() throws Exception {
		
	}

	@AfterEach
	@Override
	protected
	void tearDown() throws Exception {

	}

	@Test
	public final void test1() { //DoSave
		try
		{
			ResetDB r=new ResetDB();
			venditoreDAO.doSave(venditoreBean);
			testDao.doSave(testBean);
			list = testDao.doRetrieveAll();			
			assertTrue(list.contains(testBean));
			
		} catch(SQLException e) {
			fail(e.getMessage());
		}
	}
	
	

	
	
	@Test
	public final void test2() {//RetriveByKey

		try {
			assertEquals(testBean, testDao.doRetrieveByKey(testDao.doRetrieveAll().size()));
		} catch (SQLException e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public final void test3() {//RetriveAll

		Collection<ProdottoBean> voidList = new LinkedList<ProdottoBean>();

		try {

			assertNotEquals(voidList, testDao.doRetrieveAll());

		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}
	
	@Test
	public final void test4() { //doUpdatePezzi
		try
		{
			int pezziPrec=testDao.doRetrieveByKey(testBean.getIdProdotto()).getNumeroPezzi();
			testDao.doUpdatePezzi(testBean.getIdProdotto(),testBean.getNumeroPezzi()+1);	
			assertEquals(testDao.doRetrieveByKey(testBean.getIdProdotto()).getNumeroPezzi(),pezziPrec+1);
			
		} catch(SQLException e) {
			fail(e.getMessage());
		}
	}

	@Test
	public final void test5() {//DoUpdate

		try
		{
			ProdottoBean buf= testBean;
			buf.setDescrizione("aggiornato");
			testDao.doUpdate(buf);	
			assertEquals(testDao.doRetrieveByKey(testBean.getIdProdotto()).getDescrizione(),buf.getDescrizione());
			
		} catch(SQLException e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public final void test6() {//DoDelete

		try {

			boolean result=testDao.doDelete(testBean.getIdProdotto());
			venditoreDAO.doDelete(venditoreBean.getMail());
			assertTrue(result);

		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}
	

}

