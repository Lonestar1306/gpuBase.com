package com.gpuBase.test.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.gpuBase.model.OrdinazioneBean;
import com.gpuBase.model.OrdinazioneDAO;
import com.gpuBase.model.OrdineBean;
import com.gpuBase.model.OrdineDAO;
import com.gpuBase.model.ProdottoBean;
import com.gpuBase.model.ProdottoDAO;
import com.gpuBase.model.UtenteBean;
import com.gpuBase.model.UtenteDAO;
import com.gpuBase.model.VenditoreBean;
import com.gpuBase.model.VenditoreDAO;

import junit.framework.TestCase;

public class TestOrdineDAO extends TestCase{
	
	
	
	public TestOrdineDAO() {
		super();
		
	}

	UtenteDAO userDao =new UtenteDAO();
	UtenteBean userBean=new UtenteBean("userTest1","userPsw1","userCel1","userInd1");
	
	VenditoreDAO sellerDao =new VenditoreDAO();
	VenditoreBean sellerBean=new VenditoreBean("sellerTest1","pswTest");
	
	
	ProdottoDAO prodottoDao= new ProdottoDAO();
	ProdottoBean prodottoBean = new ProdottoBean(1,"sellerTest1","nomeProdotto","descrizioneProdotto",50,5,null);
	
	OrdinazioneDAO 	ordinazioneDao = new OrdinazioneDAO();
	OrdinazioneBean ordinazioneBean = new OrdinazioneBean(1,"userTest1","in elaborazione","2021/01/30");
	
	OrdineDAO testDao= new OrdineDAO();
	OrdineBean testBean= new OrdineBean(1,1,1,"nomeProdotto",1,5);
	

	@BeforeEach
	protected
	void setUp() throws Exception {
	}

	@AfterEach
	protected
	void tearDown() throws Exception {
	}

	@Test
	public final void test1() {//DoSave
		try {

			ResetDB r=new ResetDB();
			userDao.doSave(userBean);
			sellerDao.doSave(sellerBean);
			prodottoDao.doSave(prodottoBean);
			ordinazioneDao.doSave(ordinazioneBean);
						
			testDao.doSave(testBean);
			Collection<OrdineBean> list = testDao.doRetrieveAll();			
			assertTrue(list.contains(testBean));

		} catch (SQLException e) {
			fail(e.getMessage());
		}
	}

	

	@Test
	public final void test2() {//RetriveByKey

		try {
			assertEquals(testBean, testDao.doRetrieveByKey(testBean.getIdOrdine()));
		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}

	@Test
	public final void test3() {//RetriveAll

		ArrayList<OrdineBean> collection = new ArrayList<OrdineBean>();

		try {

			assertNotEquals(collection, testDao.doRetrieveAll());

		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}
	
	@Test
	public final void test4() {//DoDelete

		try {
			
			boolean result=testDao.doDelete(testBean.getIdOrdine());
			ordinazioneDao.doDelete(ordinazioneBean.getIdOrdinazione());
			prodottoDao.doDelete(prodottoBean.getIdProdotto());
			sellerDao.doDelete(sellerBean.getMail());
			userDao.doDelete(userBean.getMail());
		
			assertTrue(result );

		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}


}


