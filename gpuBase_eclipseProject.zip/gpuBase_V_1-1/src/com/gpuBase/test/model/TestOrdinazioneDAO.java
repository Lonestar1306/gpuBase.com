package com.gpuBase.test.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.gpuBase.model.OrdinazioneBean;
import com.gpuBase.model.OrdinazioneDAO;
import com.gpuBase.model.UtenteBean;
import com.gpuBase.model.UtenteDAO;

import junit.framework.TestCase;


public class TestOrdinazioneDAO extends TestCase{
	
	

	public TestOrdinazioneDAO() {
		super();
		
	}

	

	OrdinazioneDAO 	testDao = new OrdinazioneDAO();
	OrdinazioneBean testBean = new OrdinazioneBean(1,"userTest1","in elaborazione","2021/01/30");
	
	UtenteDAO userDao =new UtenteDAO();
	UtenteBean userBean=new UtenteBean("userTest1","userPsw1","userCel1","userInd1");
	
	Collection<OrdinazioneBean> list;

	
	@BeforeEach
	protected
	void setUp() throws Exception {
	}

	@AfterEach
	protected
	void tearDown() throws Exception {
	}
	
	
	
	@Test
	public final void test1() {//DoSave
		try {

			ResetDB r=new ResetDB();
			userDao.doSave(userBean);
			testDao.doSave(testBean);
			list = testDao.doRetrieveAll();			
			assertTrue(list.contains(testBean));

		} catch (SQLException e) {
			fail(e.getMessage());
		}
	}
	
	

	

	@Test
	public final void test2() {//RetriveByKey

		try {
			assertEquals(testBean, testDao.doRetrieveByKey(testDao.doRetrieveAll().size()));
		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}

	@Test
	public final void test3() {//RetriveAll

		Collection<OrdinazioneBean> voidList = new LinkedList<OrdinazioneBean>();

		try {

			assertNotEquals(voidList, testDao.doRetrieveAll());

		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}
	
	@Test
	public final void test4() {//DoEvade

		try {

			ResetDB r=new ResetDB();
			userDao.doSave(userBean);
			testDao.doSave(testBean);
			list = testDao.doRetrieveAll();	
			
			if(list.contains(testBean)) {
				testDao.doEvade(testBean.getIdOrdinazione());
			}
			assertNotEquals(testDao.doRetrieveByKey(testBean.getIdOrdinazione()),testBean);

		} catch (SQLException e) {
			fail(e.getMessage());
		}

		
	}
	
	@Test
	public final void test5() {//DoDelete

		try {

			boolean result=testDao.doDelete(testBean.getIdOrdinazione());
			userDao.doDelete(userBean.getMail());
			assertTrue(result );

		} catch (SQLException e) {
			fail(e.getMessage());
		}

	}
	
}
