package com.gpuBase.test.model;


import java.sql.SQLException;

import com.gpuBase.model.DriverManagerConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ResetDB{
	
	


	public ResetDB() {
		super();
		try {
			resetAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void resetAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String insertSQL1 = "delete from ordine where idOrdine>0";
		String insertSQL2 = "delete from ordinazione where idOrdinazione>0";
		String insertSQL3 = "delete from prodotto where idProdotto>0";
		String insertSQL4 = "delete from utente where mail<>\"\"";
		String insertSQL5 = "delete from venditore where mail<>\"\"";
		
		String insertSQL6 = "ALTER TABLE ordinazione AUTO_INCREMENT = 1";
		String insertSQL7= "ALTER TABLE ordine AUTO_INCREMENT = 1;";
		String insertSQL8 = "ALTER TABLE prodotto AUTO_INCREMENT = 1;";
		
		
		try {
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL1);			
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement = connection.prepareStatement(insertSQL2);			
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement = connection.prepareStatement(insertSQL3);			
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement = connection.prepareStatement(insertSQL4);			
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement = connection.prepareStatement(insertSQL5);			
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement = connection.prepareStatement(insertSQL6);			
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement = connection.prepareStatement(insertSQL7);			
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement = connection.prepareStatement(insertSQL8);			
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	
}