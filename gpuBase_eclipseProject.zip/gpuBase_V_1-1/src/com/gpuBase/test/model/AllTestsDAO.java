package com.gpuBase.test.model;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ 
	TestOrdinazioneDAO.class,
	TestOrdineDAO.class, 
	TestProdottoDAO.class, 
	TestUtenteDAO.class,
	TestVenditoreDAO.class 
	})

public class AllTestsDAO {

}
