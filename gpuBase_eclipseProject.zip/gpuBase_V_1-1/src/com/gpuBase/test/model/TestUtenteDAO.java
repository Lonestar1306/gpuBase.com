package com.gpuBase.test.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.gpuBase.model.UtenteBean;
import com.gpuBase.model.UtenteDAO;
import com.gpuBase.model.VenditoreBean;

import junit.framework.TestCase;

public class TestUtenteDAO extends TestCase{

	
	
	public TestUtenteDAO() {
		super();
	
	}

	

	UtenteDAO testDao;
	UtenteBean testBean;
	
	
	@BeforeEach
	protected
	void setUp() throws Exception {
		testDao=new UtenteDAO();
		testBean=new UtenteBean("user99","password99","cellulare99","indirizzo99");
	}

	@AfterEach
	protected
	void tearDown() throws Exception {
		testDao=null;
		testBean=null;
	}

	@Test
	public final void test1() {//DoSave
		
		try {
			ResetDB r=new ResetDB();
			testDao.doSave(testBean);
			UtenteBean testBean2=testDao.doRetrieveByKey(testBean.getMail());
			assertEquals(testBean, testBean2);

		} catch (SQLException e) {
			fail(e.getMessage());
		}
		
	}
	
	@Test
	public final void test2() {//RetriveByKey
		
		try {
			assertEquals(testBean, testDao.doRetrieveByKey(testBean.getMail()));
		} catch (SQLException e) {
			fail(e.getMessage());
		}

		
	}
	
	@Test
	public final void test3() {//RetriveAll
		ArrayList<UtenteBean> collection = new ArrayList<UtenteBean>();

		try {

			assertNotEquals(collection, testDao.doRetrieveAll());

		} catch (SQLException e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public final void test4() {//DoDelete
		try {

			assertEquals(true, testDao.doDelete(testBean.getMail()));

		} catch (SQLException e) {
			fail(e.getMessage());
		}
	}

}
